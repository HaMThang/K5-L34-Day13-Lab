# Phiếu chấm hội đồng Gate 2a

> Phiếu này điền **trong giờ duyệt chéo (17:00–17:45)**, khi nhóm mình chấm nhóm n + 1. Lúc làm bài chưa có hồ sơ của nhóm khác, nên phần dưới là mẫu trống. Kèm theo là bản nhóm tự chấm hồ sơ của mình bằng cùng thang điểm, để soát lỗi trước khi gửi.

## Phiếu chấm nhóm khác (điền khi duyệt chéo)

Nhóm được chấm: ______ · Người ghi phiếu: Người gắn nhãn 2, kiêm giữ hồ sơ

| Tiêu chí | Điểm (0 / 5 / 10) | Bằng chứng trong hồ sơ (ghi số, mục) |
|---|:---:|---|
| Đề xuất khớp bằng chứng | | |
| Số giả lập và phạm vi | | |
| Pilot ra được quyết định | | |
| **Tổng / 30** | | |

**Quyết định của hội đồng:** Go / Go có điều kiện / No-go. Lý do (1–2 câu, có số):

**Một câu hỏi cho đội trình hồ sơ:**

Gợi ý câu hỏi theo bài học hôm nay: "Chi phí mỗi việc thành công của nhóm là bao nhiêu nếu tuần đầu phải xem lại 100%?" · "Cách chia pilot của nhóm có ít nhất 20 cụm mỗi nhóm không, và cỡ mẫu hiệu dụng tối đa là bao nhiêu?" · "Ngưỡng an toàn của nhóm so với tỉ lệ mở lại 4,25% trong đợt chạy thử thì pilot có bị dừng ngay tuần đầu không?"

## Nhóm tự chấm hồ sơ của mình (trước khi gửi)

| Tiêu chí | Tự chấm | Lý do |
|---|:---:|---|
| Đề xuất khớp bằng chứng | 10 | Go có điều kiện; nêu cả con số bất lợi (B4: 0,98×, 1,03× với 15,3 phút làm lại; so công bằng 0,49×; chi phí cố định A4; quoc_te 1,88×; power 0,64 ở mức 5 điểm) và cách xử lý từng điểm |
| Số giả lập và phạm vi | 10 | Mọi số tính từ phút giả lập có nhãn [sim]; phạm vi thu hẹp về noi_dia + hang_nang, lý do bằng số từ A3 |
| Pilot ra được quyết định | 10 | Có đối chứng đồng thời, chia ngẫu nhiên 20 cụm mỗi nhóm, n hiệu dụng 859; 3 luật dừng có ngưỡng, thời hạn, người có quyền dừng. Điểm yếu tự nêu: MDE 6 thay vì 5 điểm |
