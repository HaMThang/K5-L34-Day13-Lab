# Bảng lỗi và cách khắc phục · Nhiệm vụ C

Năm loại lỗi theo Google PAIR: **ND** = do người dùng · **HT** = hệ thống · **NC** = ngữ cảnh · **GH** = giới hạn hệ thống · **NG** = ngầm.

## Hai bộ nhãn độc lập

Hai người gắn nhãn làm riêng, không trao đổi, rồi mới so.

| Ca | Tóm tắt | Người gắn nhãn 1 | Người gắn nhãn 2 | Trùng |
|---:|---|:---:|:---:|:---:|
| 1 | Khách nhập thiếu 2 số tài khoản | ND | ND | ✅ |
| 2 | Gọi tool với tham số hàng thường thay vì hàng nặng, hoàn thiếu 45.000 đ | HT | HT | ✅ |
| 3 | Hoàn về ví đúng thiết kế, khách chờ tiền về ngân hàng | NC | NC | ✅ |
| 4 | Không có dữ liệu chặng hãng nước ngoài, chuyển nhân viên | GH | GH | ✅ |
| 5 | 14 đơn có mã giảm giá bị hoàn thừa, không ai biết | NG | NG | ✅ |
| 6 | Chọn mục "giao trễ" nhưng hàng bị vỡ | ND | ND | ✅ |
| 7 | Sổ cái lỗi 503 mà vẫn báo "đã hoàn thành công" | HT | HT | ✅ |
| 8 | Dẫn điều 7.2 không tồn tại, số tiền vẫn đúng | HT | HT | ✅ |
| 9 | Nhập mã đơn của sàn thay vì mã vận đơn | ND | ND | ✅ |
| 10 | Từ chối đúng điều khoản bất khả kháng, app vẫn hiện "cam kết 24 giờ" | NC | NC | ✅ |
| 11 | Tin nhắn thoại, không xử lý được âm thanh | GH | GH | ✅ |
| 12 | Tool của D05 thiếu trường, token gấp 3 lần trong 3 tuần mà không ai thấy | NG | NG | ✅ |
| 13 | Hỏi bảo hiểm hàng hoá, ngoài phạm vi | GH | GH | ✅ |
| 14 | Bấm nhầm "Xác nhận đã nhận tiền" | ND | ND | ✅ |
| 15 | Trễ 26 giờ mà tính hoàn 100% thay vì 50%, nhân viên bắt được | HT | HT | ✅ |
| 16 | Gửi Zalo lúc 2:14 sáng theo thiết kế "gửi ngay" | NC | NC | ✅ |
| 17 | Dùng bảng giá cũ trong bộ nhớ đệm, 212 đơn lệch, không ai mở lại | NG | NG | ✅ |
| 18 | Tính đúng nhưng tin nhắn không kèm cách tính, khách mở lại | NC | NC | ✅ |
| 19 | Đơn 14 tháng, chỉ truy cập được 12 tháng, nói rõ và chuyển nhân viên | GH | GH | ✅ |
| 20 | Hoàn hai lần vì thiếu khoá chống trùng | HT | HT | ✅ |

**Tỉ lệ đồng thuận: 20/20 = 100%**, đạt ngưỡng 80% nên không phải viết lại định nghĩa.
Phân bố: ND 4 · HT 5 · NC 4 · GH 4 · NG 3.

## Quy tắc phân biệt cho các ca dễ lẫn

Hai bộ nhãn không lệch nhau ca nào. Nhóm vẫn ghi lại quy tắc cho những ca cả hai người đều phân vân khi gắn:

- **Ca 6, 9 (ND, không phải HT):** gốc lỗi là đầu vào sai của khách. Việc trợ lý không phát hiện mâu thuẫn hay không gợi ý là chỗ cần cải thiện (bước khắc phục), không phải loại lỗi. *Quy tắc: gắn nhãn theo nguyên nhân gốc, không theo chỗ cần sửa.*
- **Ca 13 (GH, không phải HT):** yêu cầu nằm ngoài phạm vi. Việc trợ lý không nói rõ giới hạn là cách thất bại kém. *Quy tắc: ngoài phạm vi hoặc thiếu dữ liệu thì là GH, kể cả khi trợ lý xử lý giới hạn đó tệ.*
- **Ca 8, 15 (HT, không phải NG):** sai đã lộ ra (trích dẫn sai nhìn thấy được; nhân viên bắt được ca 15). *Quy tắc: NG chỉ dùng khi cả khách lẫn hệ thống đều không nhận ra cho tới khi kiểm tra mẫu.*
- **Ca 18 (NC, không phải HT):** số tiền đúng chính sách, chỉ có giả định "khách hiểu cách tính" là không khớp. *Quy tắc: kết quả đúng thiết kế mà khách thấy sai thì là NC.*

## Bảng khắc phục cho 5 ca, mỗi loại một ca

| Ca | Loại lỗi | Phát hiện bằng gì (đo được) | Khắc phục thế nào | Ai phụ trách |
|---:|---|---|---|---|
| 9 | Do người dùng | Event `input_validation_failed` với `reason=ma_khong_hop_le`; đếm tỉ lệ theo ngày, cảnh báo khi > 2% số yêu cầu | Nhận diện định dạng mã sàn TMĐT, tự tra sang mã vận đơn; nếu không tra được thì hướng dẫn kèm ảnh chỗ lấy mã vận đơn, không dừng im lặng | PM trợ lý hoàn phí |
| 7 | Hệ thống | Đối soát tự động mỗi giờ: tin nhắn `refund_confirmed_to_customer` không có `ledger_write_ok` cùng trace_id; ngưỡng = 0 ca | Chỉ báo "đã hoàn" khi sổ cái trả mã thành công; lỗi 503 sau 3 lần thử thì báo "đang xử lý" và chuyển nhân viên kèm trace | Kỹ sư trưởng agent |
| 18 | Ngữ cảnh | Tỉ lệ `ticket_reopened` có `reason=so_tien` mà kiểm tra lại thấy số tiền đúng; theo dõi hằng tuần | Mẫu tin nhắn luôn ghi cách tính: "Phí 30.000 đ × 50% (trễ 24–48 giờ) = 15.000 đ", kèm link điều khoản | Trưởng nhóm CSKH (duyệt mẫu tin nhắn) |
| 4 | Giới hạn hệ thống | Event `handoff_to_staff` với `reason=thieu_du_lieu_chang`; tỉ lệ theo loại yêu cầu, xem hằng tuần | Giữ cách chuyển nhân viên kèm tóm tắt; đưa quoc_te ra khỏi phạm vi pilot (A3: thành công 27,3%); báo khách thời gian xử lý dự kiến | PM trợ lý hoàn phí |
| 17 | Ngầm | Kiểm tra mẫu hằng tuần 100 đơn: so số tiền hoàn với bảng giá hiện hành; tỉ lệ đơn lệch ≠ 0 đ, ngưỡng 1% | Xoá bộ nhớ đệm bảng giá ngay khi có bản mới (gắn số phiên bản bảng giá vào trace); kiểm tra hồi tố 212 đơn và điều chỉnh | Kế toán trưởng (chịu trách nhiệm kiểm tra mẫu; giao kỹ sư agent sửa bộ nhớ đệm) |
