"""Lab 13 · Định giá agent và lập kế hoạch pilot (Gate 2a).
Chạy: python3 lab13.py   (cần pandas; phần D dùng công thức trong Hướng dẫn học viên,
đối chiếu thêm bằng statsmodels nếu có cài).
Dữ liệu trong hai file CSV là giả lập. Mọi con số tính từ cột *_simulated đều in kèm nhãn [simulated].
"""
import math
import os

import pandas as pd

# Bảng giá GIẢ ĐỊNH của lab
GIA_VAO = 26        # đ / 1.000 token đầu vào
GIA_RA = 130        # đ / 1.000 token đầu ra
GIA_TOOL = 15       # đ / lần gọi tool
LUONG_PHUT = 2000   # đ / phút nhân viên
BASELINE = 12000    # đ / yêu cầu khi nhân viên tự làm (6 phút)


# ---------- Nhiệm vụ A1 · Kinh tế của việc chạy lại ----------
def so_lan_chay_ky_vong(p, k=None):
    """Số lần chạy trung bình; k=None nghĩa là chạy đến khi đúng."""
    if k is None:
        return 1 / p
    return (1 - (1 - p) ** k) / p


def ti_le_thanh_cong(p, k=None):
    """Xác suất thành công sau tối đa k lần chạy."""
    if k is None:
        return 1.0
    return 1 - (1 - p) ** k


def he_so_chi_phi_moi_viec_thanh_cong(p, k=None):
    """Chi phí mỗi việc thành công, theo bội số giá một lần chạy."""
    return so_lan_chay_ky_vong(p, k) / ti_le_thanh_cong(p, k)


def kiem_tra_dap_an_biet_truoc():
    assert abs(so_lan_chay_ky_vong(0.8, 2) - 1.20) < 1e-9
    assert abs(so_lan_chay_ky_vong(0.8) - 1.25) < 1e-9
    assert abs(he_so_chi_phi_moi_viec_thanh_cong(0.8, 3) - 1.25) < 1e-9
    print('Ba phép thử đáp án biết trước: ĐẠT (1,20 · 1,25 · 1,25)')


# ---------- Nhiệm vụ A2 · Mô hình chi phí từ trace ----------
def mo_hinh(runs, reqs, gia_vao=GIA_VAO, gia_ra=GIA_RA, gia_tool=GIA_TOOL,
            luong_phut=LUONG_PHUT, he_so_xem_lai=1.0, he_so_lam_lai=1.0,
            max_lan_chay=None):
    """Trả về dict các khoản chi phí. Tử số tính MỌI lần chạy (kể cả lỗi),
    mẫu số chỉ đếm yêu cầu thanh_cong.
    max_lan_chay: bỏ các lần chạy có attempt > giới hạn; yêu cầu có so_lan_chay > giới hạn
    coi là chuyen_nhan_vien, phút xem lại/làm lại = 0."""
    reqs = reqs.copy()
    runs = runs[runs['request_id'].isin(reqs['request_id'])]
    if max_lan_chay is not None:
        runs = runs[runs['attempt'] <= max_lan_chay]
        vuot = reqs['so_lan_chay'] > max_lan_chay
        reqs.loc[vuot, 'ket_qua'] = 'chuyen_nhan_vien'
        reqs.loc[vuot, ['phut_xem_lai_simulated', 'phut_lam_lai_simulated']] = 0

    tien_token_moi_run = runs['tokens_in'] / 1000 * gia_vao + runs['tokens_out'] / 1000 * gia_ra
    tien_tool_moi_run = runs['tool_calls'] * gia_tool
    token = tien_token_moi_run.sum()
    tool = tien_tool_moi_run.sum()
    chay_lai = (tien_token_moi_run + tien_tool_moi_run)[runs['attempt'] > 1].sum()
    xem_lai = reqs['phut_xem_lai_simulated'].sum() * luong_phut * he_so_xem_lai
    lam_lai = reqs['phut_lam_lai_simulated'].sum() * luong_phut * he_so_lam_lai
    tong = token + tool + xem_lai + lam_lai
    so_yc = len(reqs)
    thanh_cong = int((reqs['ket_qua'] == 'thanh_cong').sum())
    return {
        'token': token,
        'tool': tool,
        'chay_lai_attempt_gt1': chay_lai,
        'xem_lai_sim': xem_lai,
        'lam_lai_sim': lam_lai,
        'tong': tong,
        'so_yeu_cau': so_yc,
        'thanh_cong': thanh_cong,
        'cps': tong / thanh_cong if thanh_cong else float('inf'),
        'hoa_don_moi_yc': (token + tool) / so_yc,
        'lan_chay_moi_yc': len(runs) / so_yc,
        'ti_le_tc': thanh_cong / so_yc,
    }


def vnd(x):
    return f'{x:>14,.0f}'.replace(',', '.')


def pct(x, d=1):
    return f'{x * 100:.{d}f}%'.replace('.', ',')


# ---------- Nhiệm vụ D1 · Cỡ mẫu ----------
def co_mau_hai_ti_le(p1, p2, alpha=0.05, power=0.80):
    """Công thức so hai tỉ lệ trong Hướng dẫn học viên, dùng z chính xác (1,95996 và 0,84162)."""
    from statistics import NormalDist
    z_a = NormalDist().inv_cdf(1 - alpha / 2)
    z_b = NormalDist().inv_cdf(power)
    pbar = (p1 + p2) / 2
    n = (z_a * math.sqrt(2 * pbar * (1 - pbar))
         + z_b * math.sqrt(p1 * (1 - p1) + p2 * (1 - p2))) ** 2 / (p2 - p1) ** 2
    return math.ceil(n)


def he_so_thiet_ke(m, icc):
    return 1 + (m - 1) * icc


def main():
    here = os.path.dirname(os.path.abspath(__file__))
    data_dir = here if os.path.exists(os.path.join(here, 'logix_runs.csv')) else os.path.dirname(here)
    runs = pd.read_csv(os.path.join(data_dir, 'logix_runs.csv'))
    reqs = pd.read_csv(os.path.join(data_dir, 'logix_requests.csv'), keep_default_na=False)

    print('=' * 70, '\nNHIỆM VỤ A1')
    kiem_tra_dap_an_biet_truoc()

    # ----- A2
    print('=' * 70, '\nNHIỆM VỤ A2 · Mô hình chi phí (1.200 yêu cầu)')
    g = mo_hinh(runs, reqs)
    for ten, nhan in [('token', 'đo từ trace'), ('tool', 'đo từ trace'),
                      ('chay_lai_attempt_gt1', 'đo từ trace'), ('xem_lai_sim', 'simulated'),
                      ('lam_lai_sim', 'simulated'), ('tong', 'có phần simulated')]:
        print(f'{ten:22s} {vnd(g[ten])} đ   [{nhan}]')
    print(f'{"thanh_cong":22s} {g["thanh_cong"]:>14d}')
    print(f'{"cps":22s} {vnd(g["cps"])} đ   [có phần simulated]')
    print(f'{"hoa_don_moi_yc":22s} {g["hoa_don_moi_yc"]:>14,.1f} đ')
    print(f'Bội số cps / hoá đơn mỗi yêu cầu: {g["cps"] / g["hoa_don_moi_yc"]:.1f} lần')
    cac_khoan = {'token': g['token'], 'tool': g['tool'], 'xem_lai_sim': g['xem_lai_sim'], 'lam_lai_sim': g['lam_lai_sim']}
    for k, v in sorted(cac_khoan.items(), key=lambda x: -x[1]):
        print(f'  tỉ trọng {k:12s} {pct(v / g["tong"])}')

    # ----- A3
    print('=' * 70, '\nNHIỆM VỤ A3 · Theo loại yêu cầu')
    print(f'{"loai":10s} {"so_yc":>6s} {"ti_le_tc":>9s} {"chay/yc":>8s} {"cps (đ)":>12s} {"so 12.000":>10s}')
    a3 = {}
    for loai in ['noi_dia', 'hang_nang', 'quoc_te', 'doi_tac']:
        r = mo_hinh(runs, reqs[reqs['loai'] == loai])
        a3[loai] = r
        print(f'{loai:10s} {r["so_yeu_cau"]:>6d} {pct(r["ti_le_tc"]):>9s} {r["lan_chay_moi_yc"]:>8.2f} '
              f'{r["cps"]:>12,.0f} {r["cps"] / BASELINE:>9.2f}x')
    # Tỉ lệ ok ở từng lần thử, theo loại: chạy lại có giúp không?
    m = runs.merge(reqs[['request_id', 'loai']], on='request_id')
    print('Tỉ lệ ok theo lần thử (lần 2, 3 chỉ tính trên yêu cầu đã lỗi trước đó):')
    print((m.assign(ok=m['status'] == 'ok').pivot_table(index='loai', columns='attempt', values='ok', aggfunc='mean')
           .round(3)).to_string())

    # ----- B1
    print('=' * 70, '\nNHIỆM VỤ B1 · Độ nhạy (so với A2)')
    goc = g['cps']
    kich_ban = [
        ('Giá token gấp đôi', dict(gia_vao=52, gia_ra=260)),
        ('Giá token giảm một nửa', dict(gia_vao=13, gia_ra=65)),
        ('Tỉ lệ xem lại gấp đôi', dict(he_so_xem_lai=2)),
        ('Tỉ lệ xem lại giảm một nửa', dict(he_so_xem_lai=0.5)),
        ('Số ca làm lại gấp đôi', dict(he_so_lam_lai=2)),
        ('Số ca làm lại giảm một nửa', dict(he_so_lam_lai=0.5)),
        ('Lương nhân viên tăng 25%', dict(luong_phut=2500)),
        ('Chỉ cho chạy tối đa 2 lần', dict(max_lan_chay=2)),
        ('Chỉ cho chạy 1 lần', dict(max_lan_chay=1)),
        ('B2 · Token x2 + xem lại x2', dict(gia_vao=52, gia_ra=260, he_so_xem_lai=2)),
    ]
    b1 = {}
    for ten, kw in kich_ban:
        r = mo_hinh(runs, reqs, **kw)
        b1[ten] = r
        print(f'{ten:30s} {r["cps"]:>10,.0f} đ  {(r["cps"] / goc - 1) * 100:+7.1f}%')

    # ----- B3
    print('=' * 70, '\nNHIỆM VỤ B3 · Chi phí cả hệ thống theo giới hạn chạy lại')
    for k in [1, 2, 3]:
        r = mo_hinh(runs, reqs, max_lan_chay=k)
        khong_tc = r['so_yeu_cau'] - r['thanh_cong']
        he_thong = r['tong'] + BASELINE * khong_tc
        print(f'k={k}: tổng trợ lý {r["tong"]:>12,.0f} + 12.000 × {khong_tc:>3d} không thành công '
              f'= {he_thong:>12,.0f} đ | cps {r["cps"]:>8,.0f} đ | hệ thống / yêu cầu {he_thong / r["so_yeu_cau"]:>7,.0f} đ')
    print(f'So sánh: nhân viên tự làm cả 1.200 yêu cầu = {1200 * BASELINE:,.0f} đ')

    # ----- B4
    print('=' * 70, '\nNHIỆM VỤ B4 · Pilot noi_dia + hang_nang, xem lại 100% tuần đầu [simulated - giả định đề bài]')
    q4 = reqs[reqs['loai'].isin(['noi_dia', 'hang_nang'])]
    r4_runs = runs[runs['request_id'].isin(q4['request_id'])]
    co_run_ok = r4_runs[r4_runs['status'] == 'ok']['request_id'].unique()
    n_ok = len(co_run_ok)
    n_lam_lai = int((q4['ket_qua'] == 'lam_lai').sum())
    tc4 = int((q4['ket_qua'] == 'thanh_cong').sum())
    tien_may = (r4_runs['tokens_in'] / 1000 * GIA_VAO + r4_runs['tokens_out'] / 1000 * GIA_RA
                + r4_runs['tool_calls'] * GIA_TOOL).sum()
    tien_xem = n_ok * 5 * LUONG_PHUT
    tien_lam = n_lam_lai * 9 * LUONG_PHUT
    tong4 = tien_may + tien_xem + tien_lam
    print(f'{len(q4)} yêu cầu; {n_ok} có lần chạy ok → xem lại 5 phút; {n_lam_lai} ca sai → làm lại 9 phút; {tc4} thành công')
    print(f'token+tool {tien_may:,.0f} + xem lại {tien_xem:,.0f} + làm lại {tien_lam:,.0f} = {tong4:,.0f} đ')
    print(f'cps = {tong4 / tc4:,.0f} đ = {tong4 / tc4 / BASELINE:.2f}x so với 12.000 đ')

    # ----- D1
    print('=' * 70, '\nNHIỆM VỤ D1 · Cỡ mẫu (baseline 0,70, MDE 5 điểm, alpha 0,05, power 0,8, ICC 0,02)')
    icc = 0.02
    n_a = co_mau_hai_ti_le(0.70, 0.75)
    print(f'a) Chia theo yêu cầu: {n_a} yêu cầu mỗi nhóm')
    try:
        from statsmodels.stats.power import NormalIndPower
        from statsmodels.stats.proportion import proportion_effectsize
        h = proportion_effectsize(0.75, 0.70)
        n_sm = NormalIndPower().solve_power(effect_size=h, alpha=0.05, power=0.8, ratio=1)
        print(f'   (statsmodels, Cohen h: {math.ceil(n_sm)} — lệch {abs(math.ceil(n_sm) / n_a - 1) * 100:.1f}%)')
    except ImportError:
        pass
    de_b = he_so_thiet_ke(75, icc)
    n_b = n_a * de_b
    nv_b = math.ceil(math.ceil(n_b) / 75)
    print(f'b) Theo nhân viên, m=75: DE = {de_b:.2f}; n = {math.ceil(n_b)} mỗi nhóm; '
          f'{nv_b} nhân viên mỗi nhóm = {2 * nv_b} người > 40 → KHÔNG đủ người')
    print(f'c) 20 nhân viên mỗi nhóm: cỡ mẫu hiệu dụng tối đa < c/ICC = {20 / icc:.0f} < {n_a} → không đạt')
    print(f'd) 6 depot mỗi nhóm: cỡ mẫu hiệu dụng tối đa < 6/ICC = {6 / icc:.0f}')
    n_e, c_e = 859, 20
    m_e = math.ceil(n_e * (1 - icc) / (c_e - n_e * icc))
    print(f'e) MDE 6 điểm (859/nhóm), 20 nhân viên/nhóm: m ≥ {m_e} yêu cầu mỗi nhân viên '
          f'(DE {he_so_thiet_ke(m_e, icc):.2f}, hiệu dụng {c_e * m_e / he_so_thiet_ke(m_e, icc):.0f})')
    print(f'   Kiểm tra n 6 điểm bằng công thức: {co_mau_hai_ti_le(0.70, 0.76)}')

    # ----- D3 / E1 · số từ dữ liệu chạy thử
    print('=' * 70, '\nNHIỆM VỤ D3 + E1 · Chỉ số tính thử trên 1.200 yêu cầu')
    chinh = ((reqs['dong_trong_24h'] == 1) & (reqs['mo_lai_trong_7_ngay'] == 0)).mean()
    xem = reqs[reqs['duoc_xem_lai'] == 1]
    bo_qua = xem['quyet_dinh_xem_lai'].isin(['sua', 'bo']).mean()
    an_toan = (reqs['mo_lai_trong_7_ngay'] == 1).mean()
    print(f'Chính: đóng 24h & không mở lại 7 ngày = {pct(chinh, 2)}')
    print(f'Dùng: bỏ qua gợi ý (sua+bo)/được xem lại = {xem["quyet_dinh_xem_lai"].isin(["sua", "bo"]).sum()}/{len(xem)} = {pct(bo_qua, 2)}')
    print(f'An toàn: mở lại trong 7 ngày = {pct(an_toan, 2)}')
    print('Mở lại 7 ngày theo loại:')
    print(reqs.groupby('loai')['mo_lai_trong_7_ngay'].agg(['sum', 'count', 'mean']).round(4).to_string())
    pham_vi = reqs[reqs['loai'].isin(['noi_dia', 'hang_nang'])]
    print(f'Trong phạm vi pilot (noi_dia+hang_nang): mở lại = {pct(pham_vi["mo_lai_trong_7_ngay"].mean(), 2)}; '
          f'chỉ số chính = {pct(((pham_vi["dong_trong_24h"] == 1) & (pham_vi["mo_lai_trong_7_ngay"] == 0)).mean(), 2)}')
    print('Mở lại 7 ngày theo depot:')
    print(reqs.groupby('depot')['mo_lai_trong_7_ngay'].mean().round(4).to_string())

    # ----- Làm thêm: tỉ lệ thành công theo nhân viên
    print('=' * 70, '\nLÀM THÊM · Tỉ lệ thành công theo staff_id')
    s = reqs.groupby('staff_id')['ket_qua'].apply(lambda x: (x == 'thanh_cong').mean())
    print(f'{len(s)} nhân viên; min {pct(s.min())}, max {pct(s.max())}, độ lệch chuẩn {s.std() * 100:.1f} điểm')


if __name__ == '__main__':
    main()
