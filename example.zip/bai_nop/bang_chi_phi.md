# Bảng chi phí · Nhiệm vụ A và B

Nguồn: `lab13.py`, chạy trên `logix_runs.csv` (1.624 lần chạy) và `logix_requests.csv` (1.200 yêu cầu). Bảng giá là giả định của lab.
Mọi con số tính từ `phut_xem_lai_simulated` hoặc `phut_lam_lai_simulated` có nhãn **[simulated]**. Con số nào cộng cả phần đo được và phần simulated cũng mang nhãn này.

## A1 · Ba phép thử đáp án biết trước: ĐẠT

| Phép thử (p = 0,8) | Công thức | Kết quả |
|---|---|---|
| Số lần chạy trung bình, tối đa 2 lần | (1 − 0,2²) ÷ 0,8 | 1,20 ✅ |
| Số lần chạy trung bình, chạy đến khi đúng | 1 ÷ 0,8 | 1,25 ✅ |
| Chi phí mỗi việc thành công, tối đa 3 lần | [(1 − 0,2³) ÷ 0,8] ÷ (1 − 0,2³) | 1,25 ✅ |

## A2 · Mô hình chi phí từ trace

| Khoản | Số tiền (đ) | Nguồn | Nhãn |
|---|---:|---|---|
| Token | 245.585 | logix_runs.csv (mọi lần chạy, kể cả lỗi) | đo từ trace |
| Tool | 84.000 | logix_runs.csv (5.600 lần gọi × 15 đ) | đo từ trace |
| Trong đó, phần của lần chạy thứ 2 và 3 (token + tool) | 93.804 | attempt > 1 (424 lần chạy) | đo từ trace |
| Xem lại | 1.780.000 | phut_xem_lai_simulated (890 phút × 2.000 đ) | **simulated** |
| Làm lại | 2.264.000 | phut_lam_lai_simulated (1.132 phút × 2.000 đ) | **simulated** |
| Tổng chi phí | 4.373.585 | | **có phần simulated** |
| Số việc thành công | 978 | ket_qua = thanh_cong | đo từ dữ liệu |
| **Chi phí mỗi việc thành công** | **4.472** | 4.373.585 ÷ 978 | **simulated** |
| Hoá đơn token và tool chia cho số yêu cầu | 274,7 | 329.585 ÷ 1.200 | đo từ trace |

- **Chi phí mỗi việc thành công gấp 16,3 lần** con số "hoá đơn chia số yêu cầu" (4.472 so với 275 đ) [simulated].
- **Làm lại là khoản lớn nhất: 51,8% tổng chi phí** [simulated]. Xếp sau là xem lại 40,7% [simulated], token 5,6%, tool 1,9%. Giờ của nhân viên chiếm 92,5% chi phí, tiền máy chỉ 7,5%.
- Phần chạy lại (attempt > 1) chiếm 28,5% hoá đơn token + tool (93.804 / 329.585).

## A3 · Tách theo loại yêu cầu

| Loại | Số yêu cầu | Tỉ lệ thành công | Số lần chạy mỗi yêu cầu | Chi phí mỗi việc thành công [simulated] | So với 12.000 đ |
|---|---:|---:|---:|---:|---:|
| noi_dia | 824 | 95,0% | 1,11 | 2.696 đ | 0,22× |
| hang_nang | 158 | 74,1% | 1,47 | 8.221 đ | 0,69× |
| quoc_te | 150 | 27,3% | 2,32 | 22.515 đ | **1,88×** |
| doi_tac | 68 | 54,4% | 1,88 | 10.215 đ | 0,85× |

Tỉ lệ `ok` theo từng lần thử (lần 2 và 3 chỉ tính trên yêu cầu đã lỗi ở lần trước):

| Loại | Lần 1 | Lần 2 | Lần 3 |
|---|---:|---:|---:|
| noi_dia | 91,0% | 75,7% | 38,9% |
| hang_nang | 70,9% | 39,1% | 17,9% |
| quoc_te | 30,0% | 11,4% | 2,2% |
| doi_tac | 51,5% | 18,2% | 14,8% |

**Trả lời:** quoc_te không đáng để trợ lý xử lý: chỉ 27,3% thành công, trung bình 2,32 lần chạy mỗi yêu cầu, chi phí mỗi việc thành công 22.515 đ, gấp 1,88 lần nhân viên tự làm. Chạy lại tới 3 lần không giúp: lần 2 chỉ đúng 11,4%, lần 3 chỉ 2,2%. Lỗi lặp lại trên cùng yêu cầu (thiếu dữ liệu chặng nước ngoài) nên chạy thêm chỉ tốn thêm tiền. doi_tac cũng ở sát ngưỡng (0,85×, thành công 54,4%, điều khoản riêng), nên nhóm loại cả hai loại này khỏi phạm vi pilot.

## B1 · Độ nhạy (mỗi dòng đổi một yếu tố, gốc 4.472 đ) [simulated]

| Kịch bản | Cách tính | Chi phí mỗi việc thành công | Thay đổi (%) |
|---|---|---:|---:|
| Giá token gấp đôi | 52 đ và 260 đ / 1.000 token; tool giữ nguyên | 4.723 đ | +5,6% |
| Giá token giảm một nửa | 13 đ và 65 đ | 4.346 đ | −2,8% |
| Tỉ lệ xem lại gấp đôi | Tiền xem lại × 2 | 6.292 đ | +40,7% |
| Tỉ lệ xem lại giảm một nửa | Tiền xem lại ÷ 2 | 3.562 đ | −20,3% |
| Số ca làm lại gấp đôi | Tiền làm lại × 2 | 6.787 đ | **+51,8%** |
| Số ca làm lại giảm một nửa | Tiền làm lại ÷ 2 | 3.315 đ | −25,9% |
| Lương nhân viên tăng 25% | 2.500 đ / phút | 5.506 đ | +23,1% |
| Chỉ cho chạy tối đa 2 lần | bỏ attempt 3; yêu cầu chạy 3 lần → chuyen_nhan_vien, phút = 0 | 4.237 đ | −5,2% |
| Chỉ cho chạy 1 lần | bỏ attempt 2, 3 | 4.111 đ | −8,1% |

Tự kiểm tra: mỗi kịch bản "giảm một nửa" làm chi phí giảm đúng bằng nửa mức tăng của kịch bản "gấp đôi" tương ứng (5,6 → 2,8; 40,7 → 20,3; 51,8 → 25,9). ✅

## B2 · Đổi một cặp và xếp hạng

Giá token gấp đôi cùng lúc với tỉ lệ xem lại gấp đôi: **6.543 đ (+46,3%)** [simulated]. Con số này bằng tổng hai tác động riêng (5,6% + 40,7%), vì mô hình cộng tuyến tính.

Xếp hạng ba yếu tố ảnh hưởng mạnh nhất:
1. **Số ca làm lại**: ±51,8% / −25,9%
2. **Tỉ lệ xem lại**: ±40,7% / −20,3%
3. **Lương nhân viên**: +23,1% khi tăng 25%

Giá token, yếu tố hay được bàn nhất, chỉ đứng sau cùng (+5,6% khi gấp đôi). Vì vậy pilot phải theo dõi tỉ lệ làm lại và tỉ lệ xem lại, không phải hoá đơn token.

## B3 · Giới hạn chạy lại có thật sự rẻ hơn

| Giới hạn | Tổng chi phí trợ lý [simulated] | Không thành công | Chi phí cả hệ thống | Mỗi yêu cầu | Chi phí mỗi việc thành công |
|---|---:|---:|---:|---:|---:|
| 1 lần | 3.621.781 | 319 | 7.449.781 | 6.208 | 4.111 (thấp nhất) |
| **2 lần** | 4.093.220 | 234 | **6.901.220** | **5.751** | 4.237 |
| 3 lần | 4.373.585 | 222 | 7.037.585 | 5.865 | 4.472 |

Cách tính: chi phí cả hệ thống = tổng chi phí trợ lý + 12.000 đ × số yêu cầu không thành công.

**Trả lời:** giới hạn **2 lần** rẻ nhất cho công ty (6,90 triệu đ, rẻ hơn 3 lần là 136 nghìn đ và rẻ hơn 1 lần là 549 nghìn đ) [simulated]. Giới hạn này **không trùng** với giới hạn cho chi phí mỗi việc thành công thấp nhất (1 lần, 4.111 đ). Tối ưu chi phí mỗi việc thành công một mình sẽ đẩy 85 việc sang nhân viên. So với nhân viên tự làm cả 1.200 yêu cầu (14,4 triệu đ), cả ba mức đều rẻ hơn khoảng một nửa.

## B4 · Nếu phải xem lại tất cả (pilot noi_dia + hang_nang, tuần đầu) [simulated, giả định 5 và 9 phút của đề]

982 yêu cầu, trong đó 948 có lần chạy ok nên được xem lại 5 phút (9.480.000 đ). 48 ca sai bị bắt trước khi gửi, làm lại 9 phút mỗi ca (864.000 đ). Token và tool: 224.513 đ. Tổng 10.568.513 đ ÷ 900 việc thành công = **11.743 đ mỗi việc thành công, bằng 0,98 lần 12.000 đ**.

**Kết quả này nói gì:** khi xem lại 100%, trợ lý gần như không tiết kiệm được gì, vì riêng tiền xem lại đã chiếm 90% chi phí. Pilot phải học được hai điều: tỉ lệ xem lại có thể giảm an toàn xuống mức nào (ví dụ 13% như đợt chạy thử), và mỗi lần xem lại có ngắn hơn 5 phút được không.
