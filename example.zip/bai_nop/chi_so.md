# Đặc tả chỉ số, event và rủi ro kinh tế · Nhiệm vụ E1, E2

## E1 · Đặc tả chỉ số

Ba dòng đầu được tính thử trên 1.200 yêu cầu của đợt chạy thử. Đợt chạy thử **không có nhóm đối chứng**, nên đây chỉ là "chỉ số trong đợt chạy thử", không phải tác động của trợ lý.

| Loại | Chỉ số | Công thức | Tính thử trên 1.200 yêu cầu |
|---|---|---|---:|
| Chính (kết quả) | % yêu cầu đóng trong 24 giờ và không mở lại trong 7 ngày | dong_trong_24h = 1 và mo_lai_trong_7_ngay = 0, chia tổng số yêu cầu | **82,83%** (994/1.200) |
| Dùng | Tỉ lệ bỏ qua gợi ý | quyet_dinh_xem_lai là sua hoặc bo, chia số yêu cầu được xem lại | **27,12%** (48/177) |
| An toàn | Tỉ lệ lỗi lọt đến khách | mo_lai_trong_7_ngay = 1, chia tổng số yêu cầu | **4,25%** (51/1.200) |
| Dùng | Tỉ lệ mở bằng trợ lý | số yêu cầu của nhóm can thiệp có event `agent_suggestion_shown`, chia số yêu cầu được giao cho nhóm can thiệp | Không cần tính |
| An toàn | Tỉ lệ hoàn sai tiền phát hiện qua kiểm tra mẫu (bắt lỗi ngầm như ca 5, 17) | số đơn trong mẫu kiểm tra hằng tuần có \|tiền đã hoàn − tiền đúng theo chính sách\| > 0, chia số đơn được kiểm tra | Không cần tính |

Ghi chú:
- Trong phạm vi pilot (noi_dia + hang_nang), chỉ số chính là 92,26% và chỉ số an toàn là 3,97%. Baseline 0,70 do đề cho là số của nhân viên tự làm; nhóm không viết "trợ lý đã nâng chỉ số", vì pilot mới trả lời được câu đó.
- Chỉ số "bỏ qua gợi ý" chỉ đo trên 14,75% yêu cầu được xem lại, nên dễ lệch nếu nhân viên chọn ca để xem lại.

## Danh sách event

Mọi event đều mang `trace_id` để nối với trace trong `logix_runs.csv`, cùng với `request_id`, `staff_id`, `depot`, `arm` (treatment/control) và `ts`.

| # | Event | Ai tạo | Thuộc tính chính | Thời điểm |
|---:|---|---|---|---|
| 1 | `refund_request_created` | App khách / hệ thống ticket | request_id, loai, so_tien_vnd, kenh, arm, trace_id | Khi khách gửi yêu cầu |
| 2 | `agent_run_completed` | Agent | trace_id, run_id, attempt, tokens_in, tokens_out, tool_calls, status, bang_gia_version | Sau mỗi lần chạy, kể cả lần lỗi |
| 3 | `agent_suggestion_shown` | Giao diện nhân viên | trace_id, staff_id, so_tien_de_xuat, can_cu_chinh_sach | Khi gợi ý hiện cho nhân viên |
| 4 | `staff_review_decision` | Nhân viên CSKH | trace_id, quyet_dinh (giu/sua/bo), so_tien_cuoi, phut_xem_lai (đo bằng thời gian mở → bấm) | Khi nhân viên bấm gửi/sửa/bỏ |
| 5 | `staff_rework_completed` | Nhân viên CSKH | trace_id, phut_lam_lai, ly_do | Khi nhân viên tự làm lại xong |
| 6 | `refund_ledger_write` | Dịch vụ sổ cái | trace_id, idempotency_key, so_tien, ket_qua (ok/loi), ma_loi | Khi ghi sổ hoàn tiền |
| 7 | `handoff_to_staff` | Agent | trace_id, reason (het_3_lan / thieu_du_lieu / ngoai_pham_vi), tom_tat | Khi chuyển cho nhân viên |
| 8 | `ticket_closed` | Hệ thống ticket | trace_id, closed_at, gio_tu_luc_tao | Khi yêu cầu đóng |
| 9 | `ticket_reopened` | Khách / hệ thống ticket | trace_id, reopened_at, reason (so_tien / chua_nhan / khac) | Khi khách mở lại |
| 10 | `audit_sample_checked` | Kế toán (kiểm tra mẫu) | trace_id, so_tien_da_hoan, so_tien_dung, chenh_lech | Hằng tuần |

**Kiểm tra chéo: chỉ số nào tính được từ event nào**

| Chỉ số | Event cần | Đo được? |
|---|---|:---:|
| Chính: đóng 24 giờ, không mở lại 7 ngày | 1 (thời điểm tạo) + 8 (đóng) + 9 (mở lại) | ✅ |
| Dùng: tỉ lệ bỏ qua gợi ý | 4 | ✅ |
| Dùng: tỉ lệ mở bằng trợ lý | 1 (arm) + 3 | ✅ |
| An toàn: lỗi lọt đến khách | 1 + 9 | ✅ |
| An toàn: hoàn sai tiền qua kiểm tra mẫu | 10 | ✅ |
| Chi phí mỗi việc thành công (luật dừng chi phí) | 2 (token, tool) + 4, 5 (phút thật thay cho simulated) + 8, 9 | ✅ |
| Luật an toàn ca nghiêm trọng (hoàn trùng, báo sai khi sổ cái lỗi) | 6 (idempotency_key, ket_qua) + tin nhắn báo khách | ✅ |

## E2 · Rủi ro kinh tế (thêm vào risk register)

Số lấy từ bảng độ nhạy, có phần **[simulated]**.

| Rủi ro | Tác động đã tính | Dấu hiệu theo dõi | Hành động | Người phụ trách |
|---|---|---|---|---|
| Số ca làm lại tăng gấp đôi (ví dụ khi mở rộng sang hang_nang: tỉ lệ làm lại 11,4% so với 3,6% của noi_dia) | Chi phí mỗi việc thành công tăng **+51,8%**, từ 4.472 lên 6.787 đ [simulated]; yếu tố nhạy nhất | Tỉ lệ `staff_rework_completed` / yêu cầu theo tuần, theo loại; ngưỡng cảnh báo > 7% (gần gấp đôi mức 4,9% trong phạm vi) | Thu hẹp về noi_dia; rà 20 trace làm lại gần nhất; sửa tham số tool hàng nặng (ca 2) | PM trợ lý hoàn phí |
| Phải xem lại 100% lâu hơn tuần đầu | Chi phí mỗi việc thành công **11.743 đ = 0,98× nhân viên tự làm** (B4) [simulated]; xem lại gấp đôi đã +40,7% | % yêu cầu có `staff_review_decision` và phút xem lại trung bình; ngưỡng: còn > 50% ở cuối bước 0.25 | Giảm xem lại theo bậc: chỉ bắt buộc với hang_nang và đơn > 500.000 đ khi tỉ lệ sửa + bỏ < 15% | Trưởng nhóm CSKH |
| Lương nhân viên tăng 25% | **+23,1%** (5.506 đ) [simulated]; đồng thời làm baseline 12.000 đ tăng lên 15.000 đ | Đơn giá phút nhân viên trong kỳ điều chỉnh lương | Tính lại cả hai phía; lợi thế tương đối của trợ lý gần như giữ nguyên | Kế toán trưởng |
| Mở phạm vi sang quoc_te | Chi phí mỗi việc thành công 22.515 đ = **1,88×** nhân viên tự làm [simulated] | Yêu cầu muốn thêm loại vào phạm vi | Không mở trong pilot; quay lại khi có dữ liệu chặng đối tác nước ngoài | Giám đốc vận hành |
