# Hồ sơ launch v0 · Trợ lý hoàn phí LogiX-VN · Gate 2a

Dữ liệu: 1.200 yêu cầu mẫu ngẫu nhiên của đợt chạy thử 2 tuần ở 6 depot, toàn bộ là giả lập. **[sim]** đánh dấu số tính từ phút xem lại / làm lại giả lập.

| Mục | Con số chính | Trạng thái | Người phụ trách |
|---|---|---|---|
| 1 · Chi phí mỗi việc thành công | **4.472 đ** [sim], gấp 16,3 lần hoá đơn token + tool chia số yêu cầu (275 đ). 92,5% là giờ nhân viên: làm lại 51,8% [sim], xem lại 40,7% [sim]. Theo loại: noi_dia 2.696 · hang_nang 8.221 · doi_tac 10.215 · quoc_te 22.515 đ [sim] | Giả lập | PM trợ lý hoàn phí |
| 2 · Ba yếu tố nhạy nhất | Số ca làm lại (+51,8% khi gấp đôi) · tỉ lệ xem lại (+40,7%) · lương nhân viên (+23,1% khi tăng 25%) [sim]. Giá token gấp đôi chỉ +5,6% | Giả lập | PM trợ lý hoàn phí |
| 3 · So với nhân viên tự làm | So công bằng là **cả hệ thống: 5.865 đ/yêu cầu = 0,49×** của 12.000 đ (đã cộng 222 ca chuyển nhân viên) [sim]; 4.472 đ = 0,37× chỉ tính việc trợ lý làm xong. Cộng chi phí cố định 40 triệu/tháng: trong phạm vi 4.599 đ = 0,38× ở 45.000 yc/tháng, 0,48× nếu khối lượng còn một nửa (A4) [sim]. Cả hệ thống với giới hạn 3 lần, 5.751 đ với giới hạn 2 lần (rẻ nhất) [sim]. **Con số bất lợi:** nếu phải xem lại 100% thì 11.743 đ = 0,98×, và 12.414 đ = 1,03× nếu làm lại 15,3 phút/ca như dữ liệu, tức không còn tiết kiệm (B4) [sim]; quoc_te 1,88× | Giả lập | Kế toán trưởng |
| 4 · Chỉ số chính, chỉ số dùng, chỉ số an toàn | Chính: đóng 24 giờ và không mở lại 7 ngày = 82,83% trong đợt chạy thử (chưa có đối chứng; baseline nhân viên 0,70). Dùng: bỏ qua gợi ý 27,12% (48/177). An toàn: mở lại 7 ngày 4,25% (51/1.200). 10 event đều có trace_id; mọi chỉ số đều tính được từ event | Xong, có bằng chứng | Data analyst CSKH |
| 5 · Bảng lỗi và cách khắc phục | 20 ca, đồng thuận 20/20 = 100%. 5 ca khắc phục, mỗi loại một ca, có cách phát hiện đo được. Ưu tiên ca 7 (báo "đã hoàn" khi sổ cái lỗi) và ca 20 (hoàn trùng): **phải sửa trước ngày bắt đầu** | Xong, có bằng chứng | Kỹ sư trưởng agent |
| 6 · Pilot plan | Chia ngẫu nhiên theo nhân viên, 20 + 20 người, phân tầng theo depot; phạm vi noi_dia + hang_nang; ≥ 299 yêu cầu mỗi người; MDE 6 điểm (n hiệu dụng 859/nhóm, DE 6,96). **Đánh đổi:** không cách chia theo cụm nào thấy được 5 điểm với 40 người; nếu tác động thật là 5 điểm, power chỉ 0,64. 3 luật dừng (an toàn, chi phí, mức dùng), rollback 30 phút; quyết định ngày 2027-01-05 | Xong, có bằng chứng | Giám đốc vận hành |
| 7 · Rủi ro kinh tế | 5 dòng: làm lại gấp đôi +51,8% · xem lại 100% kéo dài → 0,98–1,03× · khối lượng thấp → cố định +2.370 đ/việc · lương +25% → +23,1% · mở quoc_te → 1,88× [sim] | Giả lập | Kế toán trưởng |

**Đề xuất của nhóm: Go có điều kiện.** Chỉ cho chạy pilot trong phạm vi noi_dia + hang_nang, không mở rộng ngoài kế hoạch này.

| # | Điều kiện | Người phụ trách | Ngày kiểm tra |
|---:|---|---|---|
| 1 | Có khoá chống trùng (idempotency_key) và chỉ báo "đã hoàn" khi sổ cái trả ok (ca 7, 20); chạy lại 50 ca thử, 0 lỗi | Kỹ sư trưởng agent | 2026-11-27 |
| 2 | Giám đốc vận hành ký chấp nhận MDE 6 điểm thay cho 5 điểm (power 0,64 ở mức 5 điểm), hoặc tăng số nhân viên tham gia | Giám đốc vận hành | 2026-11-27 |
| 3 | Bật đủ 10 event có trace_id trên môi trường pilot; Data analyst xác nhận tính được cả 5 chỉ số từ dữ liệu ngày đầu | Data analyst CSKH | 2026-12-01 |
| 4 | Thay hai cột phút simulated bằng phút đo thật (event 4, 5); tính lại chi phí mỗi việc thành công sau tuần 1. Nếu > 8.000 đ thì áp luật dừng chi phí | PM trợ lý hoàn phí | 2026-12-07 |
| 5 | Kế hoạch giảm xem lại theo bậc được duyệt trước bước 0.25, vì nếu vẫn xem lại 100% thì trợ lý không tiết kiệm được (B4) | Trưởng nhóm CSKH | 2026-12-07 |
